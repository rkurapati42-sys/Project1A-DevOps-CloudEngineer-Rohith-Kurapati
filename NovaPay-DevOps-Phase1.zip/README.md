# NovaPay — Production-Grade DevOps & Cloud Engineering Project

NovaPay is a hands-on DevOps portfolio project for a fictional financial platform. The repository demonstrates application delivery, containerization, database migrations, CI/CD, Kubernetes security, GitOps and observability.

## Current implementation

- Java 21 + Spring Boot REST API
- PostgreSQL 16
- Flyway database migrations
- Docker multi-stage build
- Docker Compose local environment
- GitHub Actions CI
- Gradle tests + JaCoCo coverage gate
- Trivy container scanning
- Kubernetes manifests with non-root security controls
- Kustomize dev overlay
- Argo CD GitOps application definition
- Prometheus metrics
- Grafana-ready monitoring stack

## Run locally

```bash
docker compose up --build
```

API: `http://localhost:8080`

Health: `http://localhost:8080/actuator/health`

Customers:

```bash
curl http://localhost:8080/api/v1/customers
curl -X POST http://localhost:8080/api/v1/customers \\
  -H 'Content-Type: application/json' \\
  -d '{"name":"Rohith","email":"rohith@example.com"}'
```

## Next phases

1. Add Jenkins controller/agent pipeline.
2. Add local Kubernetes deployment with kind or k3d.
3. Add PostgreSQL StatefulSet or external DB strategy.
4. Add Prometheus/Grafana dashboards and alert rules.
5. Add SonarQube and OPA/Conftest gates.
6. Add Terraform for cloud infrastructure.
7. Add staging/production promotion and canary deployment.
