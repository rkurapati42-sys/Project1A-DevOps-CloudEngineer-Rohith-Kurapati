#!/usr/bin/env bash
set -euo pipefail
min_line="${2:-80}"
min_branch="${4:-70}"
report="build/reports/jacoco/test/jacocoTestReport.xml"
[[ -f "$report" ]] || { echo "Coverage report not found: $report"; exit 1; }
python3 - "$report" "$min_line" "$min_branch" <<'PY'
import sys, xml.etree.ElementTree as ET
path, min_line, min_branch = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
root = ET.parse(path).getroot()
vals={x.attrib['type']:x for x in root.findall('counter')}
def pct(counter):
    missed=int(counter.attrib['missed']); covered=int(counter.attrib['covered']); return 100*covered/(missed+covered) if missed+covered else 100
line=pct(vals['LINE']); branch=pct(vals['BRANCH'])
print(f'Line coverage: {line:.2f}% (min {min_line:.2f}%)')
print(f'Branch coverage: {branch:.2f}% (min {min_branch:.2f}%)')
if line < min_line or branch < min_branch: raise SystemExit(1)
PY
