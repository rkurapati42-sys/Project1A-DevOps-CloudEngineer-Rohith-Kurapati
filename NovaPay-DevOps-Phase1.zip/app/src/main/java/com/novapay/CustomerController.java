package com.novapay;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {
    private final CustomerRepository repository;

    public CustomerController(CustomerRepository repository) { this.repository = repository; }

    @GetMapping
    public List<Customer> list() { return repository.findAll(); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Customer create(@RequestBody CreateCustomerRequest request) {
        if (request.name() == null || request.name().isBlank() || request.email() == null || request.email().isBlank()) {
            throw new IllegalArgumentException("name and email are required");
        }
        return repository.create(request.name(), request.email());
    }

    public record CreateCustomerRequest(String name, String email) {}
}
