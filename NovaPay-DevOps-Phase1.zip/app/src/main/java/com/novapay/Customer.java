package com.novapay;

public record Customer(Long id, String name, String email) {}
