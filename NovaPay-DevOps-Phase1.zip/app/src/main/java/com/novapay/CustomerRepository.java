package com.novapay;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CustomerRepository {
    private final JdbcTemplate jdbc;

    public CustomerRepository(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public List<Customer> findAll() {
        return jdbc.query("select id, name, email from customer_profiles order by id",
                (rs, rowNum) -> new Customer(rs.getLong("id"), rs.getString("name"), rs.getString("email")));
    }

    public Customer create(String name, String email) {
        Long id = jdbc.queryForObject(
                "insert into customer_profiles(name, email) values (?, ?) returning id",
                Long.class, name, email);
        return new Customer(id, name, email);
    }
}
