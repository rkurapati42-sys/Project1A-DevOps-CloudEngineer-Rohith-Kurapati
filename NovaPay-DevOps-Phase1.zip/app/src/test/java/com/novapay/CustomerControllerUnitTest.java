package com.novapay;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerControllerUnitTest {
    @Mock CustomerRepository repository;
    @InjectMocks CustomerController controller;

    @Test
    void listDelegatesToRepository() {
        when(repository.findAll()).thenReturn(List.of(new Customer(1L, "A", "a@example.com")));
        assertThat(controller.list()).hasSize(1);
        verify(repository).findAll();
    }

    @Test
    void createAcceptsValidRequest() {
        when(repository.create("A", "a@example.com")).thenReturn(new Customer(1L, "A", "a@example.com"));
        assertThat(controller.create(new CustomerController.CreateCustomerRequest("A", "a@example.com")).id()).isEqualTo(1L);
    }

    @Test
    void createRejectsMissingName() {
        assertThatThrownBy(() -> controller.create(new CustomerController.CreateCustomerRequest(" ", "a@example.com")))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void createRejectsMissingEmail() {
        assertThatThrownBy(() -> controller.create(new CustomerController.CreateCustomerRequest("A", "")))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
