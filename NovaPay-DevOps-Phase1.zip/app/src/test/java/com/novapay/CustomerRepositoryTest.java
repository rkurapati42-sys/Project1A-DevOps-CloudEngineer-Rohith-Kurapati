package com.novapay;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CustomerRepositoryTest {
    @Mock JdbcTemplate jdbc;
    @InjectMocks CustomerRepository repository;

    @Test
    void findAllReturnsCustomers() {
        when(jdbc.query(anyString(), any(org.springframework.jdbc.core.RowMapper.class)))
                .thenReturn(List.of(new Customer(1L, "Rohith", "r@example.com")));
        assertThat(repository.findAll()).hasSize(1).first().extracting(Customer::name).isEqualTo("Rohith");
    }

    @Test
    void createReturnsPersistedCustomer() {
        when(jdbc.queryForObject(anyString(), eq(Long.class), eq("Rohith"), eq("r@example.com"))).thenReturn(7L);
        assertThat(repository.create("Rohith", "r@example.com")).isEqualTo(new Customer(7L, "Rohith", "r@example.com"));
    }
}
