package com.novapay;

import org.junit.jupiter.api.Test;
import java.util.Map;
import static org.assertj.core.api.Assertions.assertThat;

class ApiExceptionHandlerTest {
    @Test
    void returnsErrorPayload() {
        var handler = new ApiExceptionHandler();
        assertThat(handler.badRequest(new IllegalArgumentException("bad")))
                .isEqualTo(Map.of("error", "bad"));
    }
}
