# Engineering Reflections

The project is intentionally built in phases. The first phase prioritizes a small working application and delivery path before adding cloud complexity. This makes failures easier to diagnose and gives every later DevOps component a real workload to operate.
