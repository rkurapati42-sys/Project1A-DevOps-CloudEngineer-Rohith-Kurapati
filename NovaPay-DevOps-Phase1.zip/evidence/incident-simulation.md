# Incident Simulation

## Scenario
NovaPay API latency increases after a deployment.

## Investigation
1. Check the deployment and pod rollout status.
2. Check readiness/liveness probes.
3. Review application logs and HTTP error rate.
4. Check PostgreSQL connection saturation and slow queries.
5. Compare the current image with the previous known-good image.

## Recovery
Pause promotion, roll back to the previous image, validate health and error rate, then create an RCA with the triggering change and preventive action.
